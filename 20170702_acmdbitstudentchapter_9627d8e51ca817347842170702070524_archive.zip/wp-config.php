<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
//define('WP_CACHE', true); //Added by WP-Cache Manager
define( 'WPCACHEHOME', 'C:\xampp\htdocs\wordpress\wp-content\plugins\wp-super-cache/' ); //Added by WP-Cache Manager
define('DB_NAME', 'acm_dbit');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'u`v+_FM$x~V$#ZAPD|w%PN]*hGuD/)^x]v$v{miP3,VgWS74f%PZV~:aPo|?<v}E');
define('SECURE_AUTH_KEY',  'M#~O8PqUO:xmZbcCL1*QDZ;$H9d[RkKON:Ms>S:WqqHRDScpHug_yxiBBVYo5|E$');
define('LOGGED_IN_KEY',    '@ee#%fLbnAR.?GPmN2L8XJ4P3soN+p%bo5oN~g02q|Bs9C+izR,Ck!IW{,<ja=SG');
define('NONCE_KEY',        ':*=}G%y1]WQ$a6KS9{ 12 LWL=bFEK43pRr|yQYWRgv#IxNB9}?. #u:TXIn=<*E');
define('AUTH_SALT',        'Cfpi8+++{u2sO  gn_[|jC`xbj~=0SM7h[oy7K435zlIC!_9W.4*`&zxP^2h n>A');
define('SECURE_AUTH_SALT', 'bEkY3_Et .AHb%{kip0~eE!l,P! 8QgQ4S}%k[WB@q%9s78^Sf0=,?QcQ;:<cOm!');
define('LOGGED_IN_SALT',   '$FA*(j(m<,-#W z;nEHq[7pi(:,>)E=Pm`XWIDge00G9~/>k@clV0$0d~wHCL)6U');
define('NONCE_SALT',       'kd uk7)XP^zn<;uMK^@eJ`!YdQb+:;T)SG{r+H(5ldzQYeZZYX@HpuW?$L91`8Ot');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'bixao_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
